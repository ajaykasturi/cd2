//input file
void main(){
	//declaration
	printf("hello");
	//end
}
