/*Program to print welcome message*/
void main()
{
//declaration
printf("welcome");
//End
}
