
void main(){
	
	printf("hello");
	
}
